#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time   : 2024/8/13 下午1:42
@Author : www.mingerzeng@gmail.com
@File : module.py
"""
from injector import Module



class ExtensionModule(Module):
    """擴展模塊的依賴注入"""