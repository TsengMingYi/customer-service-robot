#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time   : 2024/8/11 1:47 上午
@Author : www.mingerzeng@gmail.com
@File : __init__.py.py
"""
from .config import Config

__all__ = ['Config']