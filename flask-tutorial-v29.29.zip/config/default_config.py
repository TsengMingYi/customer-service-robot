#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time   : 2024/8/13 下午1:13
@Author : www.mingerzeng@gmail.com
@File : default_config.py
"""

# 應用默認配置項
DEFAULT_CONFIG = {
    # wtf配置
    "WTF_CSRF_ENABLED" : "False",

}
